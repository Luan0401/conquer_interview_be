# ConquerInterviewSystem
chạy project trên vs
mở terminal trong folder AIService
chạy lệnh .\venv\Scripts\activate
xong chạy lệnh python app.py
