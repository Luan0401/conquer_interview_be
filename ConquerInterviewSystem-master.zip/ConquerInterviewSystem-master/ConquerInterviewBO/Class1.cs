﻿namespace ConquerInterviewBO
{
    public class Class1
    {

    }
}
